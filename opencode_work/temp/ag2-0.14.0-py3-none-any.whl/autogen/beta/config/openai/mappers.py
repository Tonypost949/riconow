# Copyright (c) 2026, AG2ai, Inc., AG2ai open-source projects maintainers and core contributors
#
# SPDX-License-Identifier: Apache-2.0

import base64
from collections.abc import Iterable, Sequence
from typing import Any

from fast_depends.library.serializer import SerializerProto
from openai.types import CompletionUsage
from openai.types.responses import ResponseUsage

from autogen.beta.compact import CompactionSummary
from autogen.beta.config.openai.events import OpenAIReasoningEvent, OpenAIServerToolCallEvent
from autogen.beta.events import (
    BaseEvent,
    BinaryInput,
    BinaryType,
    DataInput,
    FileIdInput,
    ModelRequest,
    ModelResponse,
    TextInput,
    ToolResultsEvent,
    UrlInput,
    Usage,
)
from autogen.beta.exceptions import UnsupportedInputError, UnsupportedToolError
from autogen.beta.files.types import FileProvider
from autogen.beta.response import ResponseProto
from autogen.beta.tools.builtin.code_execution import CodeExecutionToolSchema
from autogen.beta.tools.builtin.image_generation import ImageGenerationToolSchema
from autogen.beta.tools.builtin.mcp_server import MCPServerToolSchema
from autogen.beta.tools.builtin.shell import (
    ContainerAutoEnvironment,
    ContainerReferenceEnvironment,
    ShellToolSchema,
)
from autogen.beta.tools.builtin.skills import SkillsToolSchema
from autogen.beta.tools.builtin.web_search import WebSearchToolSchema
from autogen.beta.tools.final import FunctionToolSchema
from autogen.beta.tools.schemas import ToolSchema


def response_proto_to_schema(response: ResponseProto | None) -> dict[str, Any] | None:
    """Convert a ResponseProto to Chat Completions response_format."""
    if not response or not response.json_schema:
        return

    strict_schema = _ensure_additional_properties_false(response.json_schema)
    schema: dict[str, Any] = {
        "schema": strict_schema,
        "name": response.name,
        "strict": True,
    }
    if response.description:
        schema["description"] = response.description

    return {"type": "json_schema", "json_schema": schema}


def _ensure_additional_properties_false(schema: dict[str, Any]) -> dict[str, Any]:
    """Recursively add additionalProperties: false to all object schemas.

    The OpenAI Responses API requires this on every object node.
    """
    schema = dict(schema)

    if schema.get("type") == "object":
        schema.setdefault("additionalProperties", False)

    if "properties" in schema:
        schema["properties"] = {
            k: _ensure_additional_properties_false(v) if isinstance(v, dict) else v
            for k, v in schema["properties"].items()
        }

    if "$defs" in schema:
        schema["$defs"] = {
            k: _ensure_additional_properties_false(v) if isinstance(v, dict) else v for k, v in schema["$defs"].items()
        }

    for key in ("anyOf", "oneOf", "allOf"):
        if key in schema:
            schema[key] = [
                _ensure_additional_properties_false(item) if isinstance(item, dict) else item for item in schema[key]
            ]

    if "items" in schema and isinstance(schema["items"], dict):
        schema["items"] = _ensure_additional_properties_false(schema["items"])

    return schema


def response_proto_to_text_config(
    response: ResponseProto | None,
) -> dict[str, Any] | None:
    """Convert a ResponseProto to Responses API text config."""
    if not response or not response.json_schema:
        return

    strict_schema = _ensure_additional_properties_false(response.json_schema)

    fmt: dict[str, Any] = {
        "type": "json_schema",
        "name": response.name,
        "schema": strict_schema,
        "strict": True,
    }
    if response.description:
        fmt["description"] = response.description

    return {"format": fmt}


def events_to_responses_input(
    messages: Sequence[BaseEvent],
    serializer: SerializerProto,
) -> list[dict[str, Any]]:
    """Convert a sequence of events to Responses API input items."""
    result: list[dict[str, Any]] = []
    seen_reasoning_ids: set[str] = set()

    for message in messages:
        if isinstance(message, ModelResponse):
            # Reconstruct assistant message
            content: list[dict[str, Any]] = []
            if message.message:
                content.append({"type": "output_text", "text": message.message.content})
            if content:
                result.append({"role": "assistant", "content": content})
            # Add function call items from the response
            for call in message.tool_calls.calls:
                result.append({
                    "type": "function_call",
                    "call_id": call.id,
                    "name": call.name,
                    "arguments": call.arguments,
                })

        elif isinstance(message, ToolResultsEvent):
            for r in message.results:
                blocks: list[dict[str, Any]] = []
                for part in r.result.parts:
                    if isinstance(part, TextInput):
                        blocks.append({"type": "input_text", "text": part.content})
                    elif isinstance(part, DataInput):
                        blocks.append({"type": "input_text", "text": serializer.encode(part.data).decode()})
                    elif isinstance(part, BinaryInput):
                        b64 = base64.b64encode(part.data).decode()
                        if part.kind is BinaryType.IMAGE:
                            # Images in output must use input_image (input_file rejects image/* MIME).
                            blocks.append({
                                "type": "input_image",
                                "image_url": f"data:{part.media_type};base64,{b64}",
                            })
                        elif part.kind in (BinaryType.DOCUMENT, BinaryType.BINARY):
                            # input_file with file_data *requires* filename.
                            filename = part.vendor_metadata.get("filename")
                            if not filename:
                                suffix = part.media_type.rsplit("/", 1)[-1].split("+", 1)[0]
                                filename = f"file.{suffix}"
                            blocks.append({
                                "type": "input_file",
                                "file_data": f"data:{part.media_type};base64,{b64}",
                                "filename": filename,
                            })
                        else:
                            raise UnsupportedInputError(f"BinaryInput({part.kind.value})", "openai-responses")
                    elif isinstance(part, UrlInput):
                        if part.kind is BinaryType.IMAGE:
                            blocks.append({"type": "input_image", "image_url": part.url})
                        elif part.kind in (BinaryType.DOCUMENT, BinaryType.BINARY):
                            # file_url forbids filename (API mutual-exclusion).
                            blocks.append({"type": "input_file", "file_url": part.url})
                        else:
                            raise UnsupportedInputError(f"UrlInput({part.kind.value})", "openai-responses")
                    elif isinstance(part, FileIdInput):
                        # file_id forbids filename in output (user-message allows both).
                        blocks.append({"type": "input_file", "file_id": part.file_id})
                    else:
                        raise UnsupportedInputError(type(part).__name__, "openai-responses")

                if len(blocks) == 1 and (block := blocks[0])["type"] == "input_text":
                    result.append({
                        "type": "function_call_output",
                        "call_id": r.parent_id,
                        "output": block["text"],
                    })
                else:
                    result.append({
                        "type": "function_call_output",
                        "call_id": r.parent_id,
                        "output": blocks,
                    })

        elif isinstance(message, OpenAIReasoningEvent):
            if message.item.id not in seen_reasoning_ids:
                seen_reasoning_ids.add(message.item.id)
                result.append(message.item.model_dump(exclude_none=True, mode="json"))

        elif isinstance(message, OpenAIServerToolCallEvent):
            # warnings=False: openai SDK pins ActionSearchSource.type to
            # Literal["url"] but the API returns other values (e.g. "api"),
            # which makes pydantic warn on every round-trip serialization.
            result.append(message.item.model_dump(exclude_none=True, mode="json", warnings=False))

        elif isinstance(message, ModelRequest):
            for inp in message.parts:
                if isinstance(inp, TextInput):
                    result.append({"role": "user", "content": [{"type": "input_text", "text": inp.content}]})

                elif isinstance(inp, DataInput):
                    result.append({
                        "role": "user",
                        "content": [{"type": "input_text", "text": serializer.encode(inp.data).decode()}],
                    })

                elif isinstance(inp, FileIdInput):
                    if (provider := getattr(inp, "provider", None)) and provider is not FileProvider.OPENAI:
                        raise UnsupportedInputError(
                            f"file uploaded via '{provider.value}' cannot be used with '{FileProvider.OPENAI.value}'",
                            "openai-responses",
                        )
                    # OpenAI Responses API: file_id and filename are mutually exclusive.
                    # filename applies to inline file_data, not to file_id references.
                    result.append({
                        "role": "user",
                        "content": [{"type": "input_file", "file_id": inp.file_id}],
                    })

                elif isinstance(inp, BinaryInput):
                    b64 = base64.b64encode(inp.data).decode()
                    if inp.kind is BinaryType.IMAGE:
                        image_block: dict[str, Any] = {
                            "type": "input_image",
                            "image_url": f"data:{inp.media_type};base64,{b64}",
                        }
                        if "detail" in inp.vendor_metadata:
                            image_block["detail"] = inp.vendor_metadata["detail"]
                        result.append({"role": "user", "content": [image_block]})

                    elif inp.kind in (BinaryType.DOCUMENT, BinaryType.BINARY):
                        # input_file with file_data *requires* filename.
                        filename = inp.vendor_metadata.get("filename")
                        if not filename:
                            suffix = inp.media_type.rsplit("/", 1)[-1].split("+", 1)[0]
                            filename = f"file.{suffix}"
                        result.append({
                            "role": "user",
                            "content": [
                                {
                                    "type": "input_file",
                                    "file_data": f"data:{inp.media_type};base64,{b64}",
                                    "filename": filename,
                                }
                            ],
                        })

                    else:
                        raise UnsupportedInputError(f"BinaryInput({inp.kind.value})", "openai-responses")

                elif isinstance(inp, UrlInput):
                    if inp.kind is BinaryType.IMAGE:
                        result.append({"role": "user", "content": [{"type": "input_image", "image_url": inp.url}]})

                    elif inp.kind in (BinaryType.DOCUMENT, BinaryType.BINARY):
                        result.append({"role": "user", "content": [{"type": "input_file", "file_url": inp.url}]})

                    else:
                        raise UnsupportedInputError(f"UrlInput({inp.kind.value})", "openai-responses")

                else:
                    raise UnsupportedInputError(type(inp).__name__, "openai-responses")

        elif isinstance(message, CompactionSummary):
            # Surface the summary as a user turn so it stays visible and gives a valid opening turn
            text = f"[Summary of earlier conversation]\n{message.summary}"
            result.append({"role": "user", "content": [{"type": "input_text", "text": text}]})

    return result


def convert_messages(
    system_prompt: Iterable[str],
    messages: Iterable[BaseEvent],
    serializer: SerializerProto,
) -> list[dict[str, Any]]:
    # legacy prompt message format
    result: list[dict[str, Any]] = [{"content": "\n".join(system_prompt), "role": "system"}]

    for message in messages:
        if isinstance(message, ModelResponse):
            result.append(message.to_api())

        elif isinstance(message, ToolResultsEvent):
            for r in message.results:
                parts: list[dict[str, Any]] = []
                for part in r.result.parts:
                    if isinstance(part, TextInput):
                        parts.append({"type": "text", "text": part.content})
                    elif isinstance(part, DataInput):
                        parts.append({"type": "text", "text": serializer.encode(part.data).decode()})
                    else:
                        raise UnsupportedInputError(type(part).__name__, "openai-completions")

                # Simple string content for a single plain-text turn (most common case)
                if len(parts) == 1 and parts[0]["type"] == "text":
                    result.append({"role": "tool", "tool_call_id": r.parent_id, "content": parts[0]["text"]})
                else:
                    result.append({"role": "tool", "tool_call_id": r.parent_id, "content": parts})

        elif isinstance(message, ModelRequest):
            parts: list[dict[str, Any]] = []
            for inp in message.parts:
                if isinstance(inp, TextInput):
                    parts.append({"type": "text", "text": inp.content})

                elif isinstance(inp, DataInput):
                    parts.append({"type": "text", "text": serializer.encode(inp.data).decode()})

                elif isinstance(inp, UrlInput):
                    if inp.kind is BinaryType.IMAGE:
                        parts.append({"type": "image_url", "image_url": {"url": inp.url}})

                    else:
                        raise UnsupportedInputError(f"UrlInput({inp.kind.value})", "openai-completions")

                elif isinstance(inp, FileIdInput):
                    parts.append({"type": "file", "file": {"file_id": inp.file_id}})

                elif isinstance(inp, BinaryInput):
                    if inp.kind is BinaryType.AUDIO:
                        b64 = base64.b64encode(inp.data).decode()
                        fmt = _MIME_TO_AUDIO_FORMAT.get(inp.media_type, inp.media_type.split("/", 1)[1])
                        parts.append({"type": "input_audio", "input_audio": {"data": b64, "format": fmt}})

                    elif inp.kind is BinaryType.IMAGE:
                        b64 = base64.b64encode(inp.data).decode()
                        data_url = f"data:{inp.media_type};base64,{b64}"
                        image_url: dict[str, Any] = {"url": data_url}
                        if "detail" in inp.vendor_metadata:
                            image_url["detail"] = inp.vendor_metadata["detail"]
                        parts.append({"type": "image_url", "image_url": image_url})

                    elif inp.kind is BinaryType.DOCUMENT:
                        b64 = base64.b64encode(inp.data).decode()
                        data_url = f"data:{inp.media_type};base64,{b64}"
                        filename = inp.vendor_metadata.get("filename")
                        if not filename:
                            suffix = inp.media_type.rsplit("/", 1)[-1].split("+", 1)[0]
                            filename = f"file.{suffix}"
                        parts.append({"type": "file", "file": {"file_data": data_url, "filename": filename}})

                    else:
                        raise UnsupportedInputError(f"BinaryInput({inp.kind.value})", "openai-completions")

                else:
                    raise UnsupportedInputError(type(inp).__name__, "openai-completions")

            # Simple string content for a single plain-text turn (most common case)
            if len(parts) == 1 and parts[0]["type"] == "text":
                result.append({"role": "user", "content": parts[0]["text"]})
            else:
                result.append({"role": "user", "content": parts})

        elif isinstance(message, CompactionSummary):
            # Surface the summary as a user turn so it stays visible and gives a valid opening turn
            result.append({"role": "user", "content": f"[Summary of earlier conversation]\n{message.summary}"})

    return result


def _ensure_object_schema(params: dict[str, Any]) -> dict[str, Any]:
    """OpenAI requires tool parameters to be type: object with properties."""
    schema = dict(params)
    schema["type"] = "object"
    schema.setdefault("properties", {})
    schema.setdefault("additionalProperties", False)
    return schema


def tool_to_api(t: ToolSchema) -> dict[str, Any]:
    """Chat Completions API tool format."""
    if isinstance(t, FunctionToolSchema):
        return {
            "type": "function",
            "function": {
                "name": t.function.name,
                "description": t.function.description,
                "parameters": _ensure_object_schema(t.function.parameters),
            },
        }

    raise UnsupportedToolError(t.type, "openai-completions")


def tool_to_responses_api(t: ToolSchema) -> dict[str, Any]:
    """Responses API tool format — name/description at top level."""
    if isinstance(t, FunctionToolSchema):
        return {
            "type": "function",
            "name": t.function.name,
            "description": t.function.description,
            "parameters": _ensure_object_schema(t.function.parameters),
        }

    elif isinstance(t, WebSearchToolSchema):
        result: dict[str, Any] = {"type": "web_search"}
        if t.search_context_size is not None:
            result["search_context_size"] = t.search_context_size
        if t.max_uses is not None:
            result["max_uses"] = t.max_uses
        if t.user_location is not None:
            loc: dict[str, str] = {"type": "approximate"}
            if t.user_location.city is not None:
                loc["city"] = t.user_location.city
            if t.user_location.region is not None:
                loc["region"] = t.user_location.region
            if t.user_location.country is not None:
                loc["country"] = t.user_location.country
            if t.user_location.timezone is not None:
                loc["timezone"] = t.user_location.timezone
            result["user_location"] = loc
        if t.allowed_domains is not None:
            result["filters"] = {"allowed_domains": t.allowed_domains}
        return result

    elif isinstance(t, CodeExecutionToolSchema):
        # https://developers.openai.com/api/docs/guides/tools-code-interpreter
        return {"type": "code_interpreter", "container": {"type": "auto"}}

    elif isinstance(t, ShellToolSchema):
        # https://developers.openai.com/api/docs/guides/tools-shell
        result_shell: dict[str, Any] = {"type": "shell"}
        if t.environment is not None:
            env: dict[str, Any]
            if isinstance(t.environment, ContainerAutoEnvironment):
                env = {"type": "container_auto"}
                if t.environment.network_policy is not None:
                    env["network_policy"] = {
                        "type": "allowlist",
                        "allowed_domains": t.environment.network_policy.allowed_domains,
                    }
            elif isinstance(t.environment, ContainerReferenceEnvironment):
                env = {
                    "type": "container_reference",
                    "container_id": t.environment.container_id,
                }
            else:
                env = {"type": "local"}
            result_shell["environment"] = env
        return result_shell

    elif isinstance(t, ImageGenerationToolSchema):
        result: dict[str, Any] = {"type": "image_generation"}
        if t.quality is not None:
            result["quality"] = t.quality
        if t.size is not None:
            result["size"] = t.size
        if t.background is not None:
            result["background"] = t.background
        if t.output_format is not None:
            result["output_format"] = t.output_format
        if t.output_compression is not None:
            result["output_compression"] = t.output_compression
        if t.partial_images is not None:
            result["partial_images"] = t.partial_images
        return result

    elif isinstance(t, MCPServerToolSchema):
        # https://platform.openai.com/docs/guides/tools-remote-mcp
        result = {
            "type": "mcp",
            "server_label": t.server_label,
            "server_url": t.server_url,
            "require_approval": "never",
        }
        if t.description is not None:
            result["server_description"] = t.description
        if t.allowed_tools is not None:
            result["allowed_tools"] = t.allowed_tools
        if t.headers is not None:
            result["headers"] = t.headers
        elif t.authorization_token is not None:
            result["headers"] = {"Authorization": f"Bearer {t.authorization_token}"}
        return result

    elif isinstance(t, SkillsToolSchema):
        # https://developers.openai.com/api/docs/guides/tools-skills
        raise UnsupportedToolError(t.type, "openai-responses")

    raise UnsupportedToolError(t.type, "openai-responses")


def responses_api_includes(tools: Iterable[ToolSchema]) -> list[str]:
    includes: list[str] = []
    for t in tools:
        if isinstance(t, WebSearchToolSchema):
            includes.append("web_search_call.action.sources")
    return includes


def normalize_usage(usage: CompletionUsage) -> Usage:
    return Usage(
        prompt_tokens=usage.prompt_tokens,
        completion_tokens=usage.completion_tokens,
        total_tokens=usage.total_tokens,
        cache_read_input_tokens=usage.prompt_tokens_details.cached_tokens if usage.prompt_tokens_details else None,
        thinking_tokens=usage.completion_tokens_details.reasoning_tokens if usage.completion_tokens_details else None,
    )


def normalize_responses_usage(usage: ResponseUsage) -> Usage:
    return Usage(
        prompt_tokens=usage.input_tokens,
        completion_tokens=usage.output_tokens,
        total_tokens=usage.total_tokens,
        cache_read_input_tokens=usage.input_tokens_details.cached_tokens,
        thinking_tokens=usage.output_tokens_details.reasoning_tokens,
    )


_MIME_TO_AUDIO_FORMAT: dict[str, str] = {
    "audio/wav": "wav",
    "audio/mpeg": "mp3",
    "audio/ogg": "ogg",
    "audio/flac": "flac",
    "audio/aiff": "aiff",
    "audio/aac": "aac",
}
